$(".cross").hide();
$(".hamburger").click(function () {
    $(".hamburger").hide();
    $(".menu").show();
    $(".cross").show();
    $("body:not(.menu)").css("background-color", "rgba(92, 92, 105, 0.4)");
});

$(".cross").click(function () {
    $(".cross").hide();
    $(".menu").hide();
    $(".hamburger").show();
    $("body:not(.menu)").css("background-color", "transparent");
});
$(document).ready(function() {
    $(".my-slider").slick({
      dots: true,
      // autoplay: false,
      // autoplaySpeed: 2000,
      arrows: false,
      // speed: 1000,
      slidesToShow: 1 ,
      slidesToScroll: 1,
      variableWidth: true,
      centerMode:true,
      centerPadding:true,
      lazyLoad: 'ondemand',

    //   cssEase: "cubic-bezier(0.55, 0.085, 0.68, 0.53)",
    //   responsive: [
    //     {
    //       breakpoint: 576,
    //       settings: {
    //         slidesToShow: 2,
    //         slidesToScroll: 1
    //       }
    //     }
    //   ]
    });
  });
  $(document).ready(function() {
    $(".cert-slider").slick({
      dots: false,
      autoplay: true,
      autoplaySpeed: 2000,
      arrows: false,
      speed: 1000,
      slidesToShow: 1 ,
      slidesToScroll: 1,
      variableWidth: true,

    //   cssEase: "cubic-bezier(0.55, 0.085, 0.68, 0.53)",
    //   responsive: [
    //     {
    //       breakpoint: 576,
    //       settings: {
    //         slidesToShow: 2,
    //         slidesToScroll: 1
    //       }
    //     }
    //   ]
    });
  });